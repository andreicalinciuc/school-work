#include <iostream>
#include <string>
#include <set>
#include <vector>

using namespace std;


class Song
{
public:
	string artist;
	string title;
	int year;

public:
	Song();
	Song(string _artist, string _title, int _year);
	string PrintSong();
};

class ComparatorSongByYear
{
public:
	bool operator() (const Song a, const Song b);
};

class SongCollection
{
	Song collection[100];
	int count;
public:
    SongCollection ();
    SongCollection (initializer_list <Song> args);
    SongCollection& operator += (Song S);
    SongCollection& operator = (SongCollection S);
    Song* begin();
    Song* end();
    SongCollection operator () (int b, int e);
	set<Song, ComparatorSongByYear> GetSongsByArtist(string _artist); // returneaza un set cu toate cantecele unui artist, sortate crescator dupa an
	vector<Song> GetSongsByYear(int _year); // returneaza un vector cu toate cantecele din acelasi an
};


